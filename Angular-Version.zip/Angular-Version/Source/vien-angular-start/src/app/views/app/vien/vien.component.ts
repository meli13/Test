import { Component } from '@angular/core';

@Component({
  selector: 'app-vien',
  templateUrl: './vien.component.html'
})
export class VienComponent  {

  constructor() { }

}
