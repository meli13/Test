import { Component } from '@angular/core';

@Component({
  selector: 'app-second-menu',
  templateUrl: './second-menu.component.html'
})
export class SecondMenuComponent  {

  constructor() { }
}
