import { Component } from '@angular/core';

@Component({
  selector: 'app-start',
  templateUrl: './start.component.html'
})
export class StartComponent {

  constructor() { }

}
