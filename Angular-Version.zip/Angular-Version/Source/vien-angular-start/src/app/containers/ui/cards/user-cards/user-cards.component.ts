import { Component} from '@angular/core';

@Component({
  selector: 'app-user-cards',
  templateUrl: './user-cards.component.html'
})
export class UserCardsComponent  {

  constructor() { }



}
