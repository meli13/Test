import { Component} from '@angular/core';

@Component({
  selector: 'app-image-overlay',
  templateUrl: './image-overlay.component.html'
})
export class ImageOverlayComponent {

  constructor() { }



}
