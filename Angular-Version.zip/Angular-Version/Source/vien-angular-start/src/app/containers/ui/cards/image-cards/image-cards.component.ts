import { Component } from '@angular/core';

@Component ({
  selector: 'app-image-cards',
  templateUrl: './image-cards.component.html'
})
export class ImageCardsComponent { }
