import { Component} from '@angular/core';

@Component({
  selector: 'app-custom-inputs',
  templateUrl: './custom-inputs.component.html'
})
export class CustomInputsComponent {

  constructor() { }



}
