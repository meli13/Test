import { Component} from '@angular/core';

@Component({
  selector: 'app-typeahead',
  templateUrl: './typeahead.component.html'
})
export class TypeaheadComponent  {

  constructor() { }



}
